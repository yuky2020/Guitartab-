 class Tabulatura {
  String title;
  String artist;
  String tuning = '';
  String testo = '';
  String capo = '';

 String  getTitle(){
   return this.title;
 }

}
